if __name__ == '__main__':
    from src.public import app

    app.run(debug=True)
